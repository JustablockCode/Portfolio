Paste the BruceWebUI folder into root of littlefs or sd card and restart your device.

By Justablock:D
